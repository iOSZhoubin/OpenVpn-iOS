//
//  MainViewController.m
//  OortVPN
//
//  Created by oort on 2018/6/20.
//  Copyright © 2018年 oort_vpn. All rights reserved.
//

#import "MainViewController.h"
#import "OortVPN-Swift.h"

@import NetworkExtension;

NSString * const UESRNAME = @"用户名";
NSString * const PASSWORD = @"密码";

@interface MainViewController ()

@property(strong,nonatomic) NETunnelProviderManager *providerManager;

@property(strong,nonatomic) UIButton *connBtn;


@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    
    UIButton *swiftBtn = [[UIButton alloc] init];
    [swiftBtn setFrame:CGRectMake(200, 300, 100, 50)];
    [swiftBtn setTitle:@"跳转swift去连接" forState:UIControlStateNormal];
    [swiftBtn setBackgroundColor:[UIColor orangeColor]];
    [swiftBtn addTarget:self action:@selector(pushSwiftVc) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:swiftBtn];
    
    
    UIButton *closeBtn = [[UIButton alloc] init];
    [closeBtn setFrame:CGRectMake(200, 100, 100, 50)];
    [closeBtn setTitle:@"断开连接" forState:UIControlStateNormal];
    [closeBtn setBackgroundColor:[UIColor orangeColor]];
    [closeBtn addTarget:self action:@selector(dissconnection) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:closeBtn];
    
    
    self.connBtn = [[UIButton alloc] init];
    [self.connBtn setFrame:CGRectMake(0, 0, 100, 50)];
    [self.connBtn setCenter:self.view.center];
    [self.connBtn setTitle:@"连接" forState:UIControlStateNormal];
    [self.connBtn setBackgroundColor:[UIColor orangeColor]];
    [self.connBtn addTarget:self action:@selector(connection) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.connBtn];
    
    [NETunnelProviderManager loadAllFromPreferencesWithCompletionHandler:^(NSArray<NETunnelProviderManager *> * _Nullable managers, NSError * _Nullable error) {
        if(error){
            return ;
        }
        self.providerManager = managers.firstObject?managers.firstObject:[NETunnelProviderManager new];
        [self initProvider];

    }];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onVpnStateChange:) name:NEVPNStatusDidChangeNotification object:nil];
}
-(void)onVpnStateChange:(NSNotification *)Notification {
    
    switch (self.providerManager.connection.status) {
        case NEVPNStatusInvalid:
            NSLog(@"链接无效");
            break;
        case NEVPNStatusDisconnected:
            NSLog(@"未连接");
            break;
        case NEVPNStatusConnecting:
            NSLog(@"正在连接");
            break;
        case NEVPNStatusConnected:
            NSLog(@"已连接");
            break;
        case NEVPNStatusDisconnecting:
            NSLog(@"断开连接");
            break;
        case NEVPNStatusReasserting:
            NSLog(@"********************ReConnecting******************");
            break;
        default:
            break;
            
    }
}

-(void)initProvider{
    NETunnelProviderProtocol *tunel = [[NETunnelProviderProtocol alloc] init];
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"vpnclient" withExtension:@"ovpn"];
    NSData *data = [[NSData alloc] initWithContentsOfURL:url];
    tunel.providerConfiguration = @{@"ovpn": data};
    tunel.providerBundleIdentifier = @"子项目的Bundel Identifier";
    tunel.serverAddress = @"oortopenvpn.org";
    tunel.disconnectOnSleep = NO;
    [self.providerManager setEnabled:YES];
    [self.providerManager setProtocolConfiguration:tunel];
    self.providerManager.localizedDescription = @"OortVPN";
    [self.providerManager saveToPreferencesWithCompletionHandler:^(NSError *error) {
        if(error) {
            NSLog(@"Save error: %@", error);
        }else {
            NSLog(@"add success");
            [self.providerManager loadFromPreferencesWithCompletionHandler:^(NSError * _Nullable error) {
                NSLog(@"loadFromPreferences!");
            }];
        }
    }];
    
}


-(void)dissconnection
{
    [self.providerManager.connection stopVPNTunnel];
}

- (void)connection{
    [self.providerManager loadFromPreferencesWithCompletionHandler:^(NSError * _Nullable error) {
        if(!error){
            NSError *error = nil;
            [self.providerManager.connection startVPNTunnelWithOptions:nil andReturnError:&error];
            if(error) {
                NSLog(@"Start error: %@", error.localizedDescription);
            }else{
                NSLog(@"Connection established!");
            }
        }
    }];
    
}


-(void)pushSwiftVc
{
    SwiftViewController *vc = [[SwiftViewController alloc]init];
    
    [self.navigationController pushViewController:vc animated:YES];
}

@end
