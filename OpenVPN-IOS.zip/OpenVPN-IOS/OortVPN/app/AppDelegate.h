//
//  AppDelegate.h
//  OortVPN
//
//  Created by oort on 2018/6/20.
//  Copyright © 2018年 oort_vpn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

