//
//  NEPacketTunnelFlow+NEPacketTunnelFlow_Extension.h
//  PacketTunnel
//
//  Created by oort on 2018/6/20.
//  Copyright © 2018年 oort_vpn. All rights reserved.
//

#import <NetworkExtension/NetworkExtension.h>

@interface NEPacketTunnelFlow ()<OpenVPNAdapterPacketFlow>

@end
