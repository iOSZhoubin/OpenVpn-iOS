//
//  PacketTunnelProvider.h
//  TargetTunnel
//
//
//

@import NetworkExtension;
@import OpenVPNAdapter;

NS_ASSUME_NONNULL_BEGIN

@interface PacketTunnelProvider : NEPacketTunnelProvider

@property(nonatomic,strong) OpenVPNAdapter *vpnAdapter;

@property(nonatomic,strong) OpenVPNReachability *openVpnReach;

typedef void(^StartHandler)(NSError * _Nullable);
typedef void(^StopHandler)(void);

@property(nonatomic,copy) StartHandler __nullable startHandler;
@property(nonatomic,copy) StopHandler __nullable stopHandler;

@end

NS_ASSUME_NONNULL_END
