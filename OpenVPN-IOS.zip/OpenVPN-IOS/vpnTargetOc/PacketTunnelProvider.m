//
//  PacketTunnelProvider.m
//  TargetTunnel
//

#import "PacketTunnelProvider.h"
#include "NEPacketTunnelFlow+NEPacketTunnelFlow_Extension.h"

@interface PacketTunnelProvider ()<OpenVPNAdapterDelegate>
// 这个先放下，一会讲，主要用到和父项目进行通信
@property (strong,nonatomic) NSUserDefaults *userDefaults;

@end

@implementation PacketTunnelProvider

// 懒加载
-(OpenVPNAdapter*)vpnAdapter{
    
    if(!_vpnAdapter){
        
        _vpnAdapter = [[OpenVPNAdapter alloc] init];
        
        _vpnAdapter.delegate = self;
    }
    
    return _vpnAdapter;
}


-(OpenVPNReachability*)openVpnReach{
    
    if(!_openVpnReach){
        
        _openVpnReach = [[OpenVPNReachability alloc] init];
    }
    
    return _openVpnReach;
}

-(void)startTunnelWithOptions:(NSDictionary<NSString *,NSObject *> *)options completionHandler:(void (^)(NSError * _Nullable))completionHandler
{
    NETunnelProviderProtocol *proto =  (NETunnelProviderProtocol*)self.protocolConfiguration;
    
    if(!proto){
        
        return;
    }
    
    NSDictionary<NSString *,id> *provider = proto.providerConfiguration;
        
    NSData * fileContent = provider[@"ovpn"];
    
//    NSString * str1  = [[NSString alloc] initWithData:fileContent encoding:NSUTF8StringEncoding];


    OpenVPNConfiguration *openVpnConfiguration = [[OpenVPNConfiguration alloc] init];
    
    openVpnConfiguration.keyDirection = 1;
    
    openVpnConfiguration.fileContent = fileContent;
    // If true, don't send client cert/key to peer.
    openVpnConfiguration.disableClientCert = NO;
    // 用户名和密码进行认证
//    openVpnConfiguration.settings = @{@"username":@"",@"password":@""};
//    如果要在暂停或重新连接期间保持TUN接口处于活动状态，请取消对此行的注释
//    openVpnConfiguration.tunPersist = YES;
    
    NSError *error;

    OpenVPNProperties *evaluation = [self.vpnAdapter applyConfiguration:openVpnConfiguration error:&error];

    if(error){

        completionHandler(error);

        return;
    }
    // 配置用户名和密码
    if (!evaluation.autologin)
    {
        OpenVPNCredentials *tials = [[OpenVPNCredentials alloc]init];

        tials.username = [NSString stringWithFormat:@"%@",[options objectForKey:@"username"]];

        tials.password = [NSString stringWithFormat:@"%@",[options objectForKey:@"password"]];

        [self.vpnAdapter provideCredentials:tials error:&error];

        if(error){

            completionHandler(error);
            return;
        }
    }
    
    [self.openVpnReach startTrackingWithCallback:^(OpenVPNReachabilityStatus status) {
        
        if(status==OpenVPNReachabilityStatusReachableViaWiFi){
        
            [self.vpnAdapter reconnectAfterTimeInterval:5];
        }
    }];
    
    //建立连接并等待。关联事件
    self.startHandler = completionHandler;


    [self.vpnAdapter connect];
    
}


-(void)stopTunnelWithReason:(NEProviderStopReason)reason completionHandler:(void (^)(void))completionHandler
{
    self.stopHandler = completionHandler;

    if ([self.openVpnReach isTracking]) {
        // vpn被主动关闭
        [self.openVpnReach stopTracking];
    }
    
    [self.vpnAdapter disconnect];
}



- (void)openVPNAdapter:(nonnull OpenVPNAdapter *)openVPNAdapter configureTunnelWithNetworkSettings:(nullable NEPacketTunnelNetworkSettings *)networkSettings completionHandler:(nonnull void (^)(NSError * _Nullable))completionHandler {
    
    
    __weak __typeof(self) weak_self = self;
    
    [self setTunnelNetworkSettings:networkSettings completionHandler:^(NSError * _Nullable error) {
       
        if(!error){

            completionHandler(weak_self.packetFlow);
        }
    }];
}

- (void)openVPNAdapter:(nonnull OpenVPNAdapter *)openVPNAdapter handleError:(nonnull NSError *)error {

    BOOL isOpen = (BOOL)[error userInfo][OpenVPNAdapterErrorFatalKey];
    
    NSLog(@"isOpen = %d ",isOpen);

    if(isOpen){
    
        if (self.openVpnReach.isTracking) {
        
            [self.openVpnReach stopTracking];
        }
        
        if (error)
        {
            self.startHandler(error);
        }
                
        self.startHandler = nil;
    }
}

- (void)openVPNAdapter:(nonnull OpenVPNAdapter *)openVPNAdapter handleEvent:(OpenVPNAdapterEvent)event message:(nullable NSString *)message {
    
    switch (event) {
        case OpenVPNAdapterEventConnected:
        {
            if(self.reasserting){
                
                self.reasserting = false;
            }
            
            self.startHandler(nil);
            
            self.startHandler = nil;
        }
            break;
        case OpenVPNAdapterEventDisconnected:
        {
            if (self.openVpnReach.isTracking) {
                
                [self.openVpnReach stopTracking];
            }
            
            self.stopHandler();
            
            self.stopHandler = nil;
        }
            break;
        case OpenVPNAdapterEventReconnecting:
            self.reasserting = true;
            break;
        default:
            break;
    }
}

@end
